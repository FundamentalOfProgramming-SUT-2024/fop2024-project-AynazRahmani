# Project

## شما می‌توانید داک‌های هر فاز پروژه را از لینک‌های زیر دانلود کنید:
فاز اول: 

https://github.com/FundamentalOfProgramming-SUT-2024/fundamentalofprogramming-sut-2024-classroom-fop2024_project-Rogue_Project/blob/main/FOP_Project2024-Phase1.pdf
